# Voli economici Cuba — prototipo Android

## Cosa fa questa prima versione
- Aggiunge un widget alla schermata iniziale Android.
- Imposta la ricerca di sola andata da Milano (codice multi-aeroporto MIL, che comprende gli aeroporti milanesi) verso L'Avana (HAV), con date dal 13 ottobre al 30 novembre 2026.
- Apre Skyscanner nel browser quando si tocca il pulsante.

## Limiti dichiarati
Questa è una **prima bozza del widget**, non ancora il prodotto completo richiesto: non legge automaticamente i prezzi e quindi non mostra un prezzo minimo reale. Per farlo serve l'accesso a un'API di tariffe autorizzata, credenziali e integrazione del relativo formato di risposta. Non inserire chiavi API segrete direttamente nel codice Android: andrebbero protette da un servizio backend.

Android limita gli aggiornamenti periodici dei widget; un aggiornamento esatto ogni minuto non è garantibile. Il provider non è configurato per simulare aggiornamenti o prezzi inesistenti.

## Compilazione
Aprire questa cartella in Android Studio aggiornato e lasciare che Gradle sincronizzi il progetto. Poi selezionare `Build > Build APK(s)`. Il file APK di debug sarà normalmente in `app/build/outputs/apk/debug/`.

Questo archivio contiene il codice sorgente, non un APK già compilato.
