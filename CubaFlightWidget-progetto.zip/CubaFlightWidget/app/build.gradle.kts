plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "it.cubaflight.widget"
    compileSdk = 35

    defaultConfig {
        applicationId = "it.cubaflight.widget"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototipo"
    }
}
