package it.cubaflight.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Prototipo del widget. Non dichiara un prezzo perché non è ancora collegato
 * a un'API autorizzata per le tariffe. Il pulsante apre la ricerca esterna.
 */
class CubaFlightWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.cuba_flight_widget)
            val url = Uri.parse(
                "https://www.skyscanner.it/trasporti/voli/mila/hava/261013/261130/?adultsv2=1&cabinclass=economy&currency=EUR&locale=it-IT&market=IT&rtn=0"
            )
            val intent = Intent(Intent.ACTION_VIEW, url)
            val pending = PendingIntent.getActivity(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.search_button, pending)
            views.setOnClickPendingIntent(R.id.price, pending)
            val checked = SimpleDateFormat("dd/MM HH:mm", Locale.ITALY).format(Date())
            views.setTextViewText(R.id.details, "Ricerca esterna · aperta da widget · $checked")
            manager.updateAppWidget(id, views)
        }
    }
}
